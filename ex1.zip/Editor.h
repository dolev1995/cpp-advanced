#pragma once
#include "Document.h"
#include <iostream>
#include <fstream>
#include <string>
using namespace std;
namespace edit{


    class Editor{

    private:
        Document doc;
        void loop();

    public:

        Editor(){
            Editor::loop();
        }

        Editor(string f){
            ifstream myfile(f);
            if(myfile.is_open())
            {
                string line;
                while ( getline (myfile,line) )
                {
                    doc._lines.push_back(line);
                }
                myfile.close();
            }
            loop();
        }


    };
}