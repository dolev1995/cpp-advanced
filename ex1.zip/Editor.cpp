#include "Editor.h"
#include <algorithm>
using std::count;
#include <string>
using std::string; using std::stoi;
#include <iostream>
using std::cin; using std::cout;using std::endl; 
using namespace edit;

void Editor::loop(){
    bool quit = false;
    string input;

    while(!quit){
        getline(cin,input);
        if(!input.compare("a")){
            doc.insert_after();        
        }
        else if(!input.compare("i")){
            doc.insert_before();
        }
        else if (input.find("+") == 0) //(!input.compare("+"))
        {
          cout << "We are here +++" << endl;
            doc.change_iterator_plus(stoi(input.substr(1)));
        }
        else if(input.find("-") == 0)
        {
            doc.change_iterator_sub(stoi(input.substr(1)));
        }
        else if(std::isdigit(input[0])) //אם קיבלתי מספר
        {
            	doc.updateLine(stoi(input.substr(0)));
        }
        else if(!input.compare("$"))
        {
            doc.changeCurrentToEnd();
        }

        else if(!input.compare("j"))
        {
          doc.additionLine();
        }

            else if (!input.compare("c")) {
              doc.change();
            }
            else if (!input.compare("d")) {
                doc.deleteCurrent();
            }
           else if (!input.substr(0, 2).compare("s/") ) {
                //cout << input << endl;
                cout << "We are in replace" << endl;
                doc.replaceStringInCurrent(input);
            }

          
        else if (!input.substr(0, 1).compare("w"))
        {
                doc.w_file(input.substr(1));
        }
            else if (!input.compare("q")) {
                quit = true;
            }
        else if (input.find("/") == 0) {
              doc.search(input);
          }
              else {
                doc._lines.push_back(input);
              }
              cout << "Input: " << input << endl;
            for ( string s : doc._lines) {
              cout << s << endl;
            }
            cout << "END" << endl;
    }

	//cout <<"a\nPOEM\nI have eaten\nthe strawberries\nand the peaches\nthe icebox\nyou were\n.\np\nyou were\nn\n7 you were\n? POEM\nPOEM\nn\n1 POEM\n/ thethe strawberries\n/ \nand the peaches\n/ \nthe icebox\n7\nyou were\n2\nI have eaten\nn\n2 I have eaten\n4\nand the peaches\na\nthat were in\n.\nn\n5 that were in\n8\nyou were\ni\nand which\n.\n9\nyou were\nn\n9 you were\nc\nyou were probably\n.\n4\nand the peaches\nd\n8\nyou were probably\nn\n8 you were probably\na\nsaving\nfor breakfast\n\nForgive me\nthey were delicious\nso sweet\nand so cold\n.\n/ strawberries\nthe strawberries\ns / strawberries / plums / \n% p\nPOEM\nI have eaten\nthe plums\nthat were in\nthe icebox\n\nand which\nyou were probably\nsaving\nfor breakfast\n\nForgive me\nthey were delicious\nso sweet\nand so cold\nQ\n" ;
} 