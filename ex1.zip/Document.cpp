#include "Document.h"
#include <fstream>
#include <iterator>
#include <vector>
using std::vector;
#include <string>
using std::string; 
#include <iostream>
using std::cout; using std::endl; using std::cin; using std::getline;


Document::Document() {
    currentLine = -1;
    //currentLine = 1;
}


void Document::changeCurrentToEnd(){
		currentLine = _lines.size() -1;
	}

  void Document::additionLine()    //j
  {
    _lines[currentLine] += " " + _lines[currentLine+1];
    currentLine++;
    deleteCurrent();
  }

void Document::insert_after(){  // a

   change_iterator_plus(1);
   insert_before();
}
          
        
  void Document::insert_before(){           //i
    bool noDot = true;
    string text;

    while(noDot){
        getline(cin, text);
        if(text == "."){
            noDot = false;
        }
        else{
            _lines.insert(_lines.begin() + currentLine, text);
            //_lines.insert(_lines.begin()+currentLine, text);
            currentLine++;
        }
    }
    currentLine--;
  }



void Document::deleteCurrent(){

	_lines.erase(_lines.begin()+currentLine);
    currentLine--;
}


void Document::repeatSearch(){
    search(_lastSearch);
}

void Document::search(string text){
  text = text.substr(1, text.length()-1-1);
  for (int i = 1; i <= _lines.size(); i++) {
    int l = (currentLine+i) % _lines.size();
    if (_lines[l].find(text) != string::npos) {
      currentLine = l;
    }
  }
    }


void Document::replaceStringInCurrent(string input){

    cout << input.length() << endl;
    string oldNNew = input.substr(2,input.length()-1-2); //cut unnecessary head and tail
    cout << oldNNew.length() << endl;
    cout << oldNNew << endl;
    size_t middle = oldNNew.find('/');
    string oldString = oldNNew.substr(0,middle); 
    cout << oldString << endl;
    string newString =oldNNew.substr(middle+1);
    cout << newString << endl;

    size_t index = _lines[currentLine].find(oldString);
    if(index != string::npos){	
		_lines[currentLine].replace(index , oldString.length(), newString);
    }

}

void Document::w_file(string input) 
{
    string name_file = input.substr(1); 
    std::ofstream output_file(name_file);
    std::ostream_iterator<std::string> output_iterator(output_file, "\n");
    std::copy(_lines.begin(), _lines.end(), output_iterator);
}


void Document::change_iterator_plus(int n)
{
  currentLine += n;
  while (_lines.size() < currentLine)
    _lines.push_back("");
}

void Document::change_iterator_sub(int n)
{
  currentLine = std::max(0, currentLine-n);

}

void Document::updateLine(int x){
    currentLine = x-1;
}

void Document::change()
{
  deleteCurrent();
	insert_after();
}



