#include "Editor.h"
#include <string>
#include <iostream>
using namespace edit;
//using namespace std;

int main(int argc, char* argv[]) {
switch (argc) {
  case 1:{
    Editor editor1;
    break;
  }
  case 2:{
    string file_read = argv[1];
    Editor editor2(file_read);
    break;
  }
  default:
  {
    return 0;
  }
}
return 0;
}