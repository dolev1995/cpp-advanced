#pragma once

#include <vector>
using std::vector;
#include <string>
using std::string;

class Document{

//private:
public:
  vector<std::string> _lines;
  string _lastSearch;
	int currentLine;


    Document();
    
    /*prints the current line*/
   // void printCurrentLine();
    /*prints the current line number then TAB then its content*/
    //void printNumberedCurrentLine();
    /*prints all lines*/
    //void printAll();
    /*changes current line to the line number it gets*/
    void changeCurrentTo(unsigned int newCurrent );
    /*starts writing mode*/
    void insert_after();
    void insert_before();
    
	//?????????????????????????/
	/*changes the  current line for text that follows*/
    //void forwardCurrent();

    /*deletes the current line*/
    void deleteCurrent();
    /*search after the current line*/
    void search(string text);
    /*repeat last search*/
    void repeatSearch();
    /*searches for specific text after the current line and makeing hiqs line the current */
    //void searchAbove(string text);
    /*replace current line neww one*/
    
    void replaceCurrentLine();
    /*replace this string int current line with new string */
    void replaceStringInCurrent(string input);

    // write vector to a file
    void w_file(string s);

    void change_iterator_plus(int n);

    void change_iterator_sub(int n);

    void changeCurrentToEnd();    //$

    void additionLine();    //j

    void updateLine(int x);
    void change();
};
