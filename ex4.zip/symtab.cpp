#include "symtab.h"
#include "scanner.h"

Attributes& Symbol_table::get(string name)
{
  auto f = sym_tab.find(name);
  return (f->second);
}

void Symbol_table::set(string name, double nv)
{
  auto f = sym_tab.find(name);
  if(f->second.is_const == true)
  {
    error("cannot change constant");
    return;
  }
  else   f->second.value = nv;
}

bool Symbol_table::is_declared(string name)
{
    bool i;
    auto f = sym_tab.find(name);
     (f != sym_tab.end())? i = true : i = false;
     return i;
}

void Symbol_table::declare(string name, double nv, bool ic)
{
  //auto a = ({name,attributes});
   //sym_tab.insert({name, Attributes attributes(nv,ic)});
  Attributes attributes(nv,ic);
  sym_tab.insert({name,attributes});
}

