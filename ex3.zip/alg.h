#pragma once
#include <algorithm>
#include <iterator>
#include <iostream>
#include <math.h>

using std::cout; using std::endl;

//from geeksforgeeks
bool isPerfectSquare(int x) 
{ 
    int s = sqrt(x); 
    return (s*s == x); 
} 
  
// Returns true if n is a Fibinacci Number, else false 
bool isFibonacci(int n) 
{ 
    // n is Fibinacci if one of 5*n*n + 4 or 5*n*n - 4 or both 
    // is a perferct square 
    return isPerfectSquare(5*n*n + 4) || 
           isPerfectSquare(5*n*n - 4); 
} 

template <typename T>
bool Fib(T beg, T end)
{
  for(auto i = beg; beg!=end; i++)
  {
      if(!isFibonacci(*i))
      {
            return false;
      }
      beg++;
  }
    return true;
}




//transpose
template <typename T>
const T Transpose(const T& b_it, const T& e_it)
{

  if(b_it == e_it) return b_it;
  int length = std::distance(b_it,e_it);
  T it = b_it;
	if (length % 2 == 0)
{
	for (int i = 0; i < length-1; i += 2)
		std::iter_swap(it + i, it + (i + 1));
  return e_it ;
}
	else
		return b_it;
};

//transform2

template<typename T1, typename T2, typename F>
T2 Transform2(const T1& b,const T1& e,const T2& beg, F f){
 T1 beg1 = b;
 T1 end1 = e;
 T2 beg2 = beg;
 int length = std::distance(b,e);
 if (length % 2 == 0)
{
	for (int i = 0; i < length-1; i += 2)
  {
		*beg2 = f(*(beg1 + i), *(beg1 + (i + 1)));
    ++beg2;
  }
  return beg2;
}
else
{
  for (int i = 0; i < length-2; i += 2)
  {
		*beg2 = f(*(beg1 + i), *(beg1 + (i + 1)));
    ++beg2;
  }
  return beg2;
}
	
};