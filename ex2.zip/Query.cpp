#include "Query.h"
#include "TextQuery.h"
#include <memory>
#include <set>
#include <algorithm>
#include <iostream>
#include <cstddef>
#include <iterator>
#include <stdexcept>
#include <regex>
#include <sstream>
#include <string>


using namespace std;
/////////////////////////////////////////////////////////
shared_ptr<QueryBase> QueryBase::factory(const string& s)
{      
  vector<string> st;
	istringstream re(s);

	for (string line; re >> line;) st.push_back(line);
	if (st.size() == 1) 
    return std::shared_ptr<QueryBase>(new WordQuery(st[0]));
	else if (st.size() == 3 && st[0] == "OR")
    return   std::shared_ptr<QueryBase>(new OrQuery(st[1],st[2]));
	else if (st.size() == 3 && st[0] == "AND")
    return std::shared_ptr<QueryBase>(new AndQuery(st[1],st[2]));
	else if (st.size() == 3 && st[0] == "AD") 	
    return std::shared_ptr<QueryBase>(new AdjacentQuery(st[1],st[2]));
	else 
    throw std::invalid_argument("Unrecognized search\n");
}
// . . .

/////////////////////////////////////////////////////////
QueryResult AndQuery::eval (const TextQuery& text) const
{
    QueryResult left_result = text.query(left_query);
    QueryResult right_result = text.query(right_query);
    auto ret_lines = make_shared<set<line_no>>();
    set_intersection(left_result.begin(), left_result.end(),
        right_result.begin(), right_result.end(), 
        inserter(*ret_lines, ret_lines->begin()));
   return QueryResult(rep(), ret_lines, left_result.get_file());
}

QueryResult OrQuery::eval(const TextQuery &text) const
{
    QueryResult left_result = text.query(left_query);
    QueryResult right_result = text.query(right_query);
    auto ret_lines = make_shared<set<line_no>>(left_result.begin(), left_result.end());
    ret_lines->insert(right_result.begin(), right_result.end());
    return QueryResult(rep(), ret_lines, left_result.get_file());
}
/////////////////////////////////////////////////////////
QueryResult AdjacentQuery::eval (const TextQuery& text) const
{

  
  QueryResult left_result = text.query(left_query);
  QueryResult right_result = text.query(right_query);
  auto ret_lines = make_shared<set<line_no>>();


  for(auto i= left_result.begin();i != left_result.end();i++)
  {
    for(auto j= right_result.begin();j != right_result.end();j++)
    {
      int temp = *i-*j;
      if(temp == 1 || temp == -1)
      {
        ret_lines->insert(*j);
        ret_lines->insert(*i);        
      }
    }
  }
  return QueryResult(rep(), ret_lines, left_result.get_file());
}
          



/////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////
std::ostream &print(std::ostream &os, const QueryResult &qr)
{
 

int num_1 = 0;
int num_2 = 0;
if(qr.sought.find("AD") != string::npos)  //get AD
{   
    if(qr.lines->size()==3)   //occurs 2
    {
      string word = qr.sought;
      os << "\"" << word << "\"" << " occurs 2"  << " times:" <<std::endl;
      for (auto num : *qr.lines)
      {
        os << "\t(line " << num + 1 << ") " 
            << *(qr.file->begin() + num) << std::endl;
        num_1++;
  
        if(((num_1)%2 == 0)&&(num_1 != qr.lines->size())) os << "\n";

        if(num_1 == qr.lines->size()-1)
          os << "\t(line " << num + 1 << ") " << *(qr.file->begin() + num) << std::endl;
      }
      return os;
    }
    else
    { 
      auto temp = qr.lines->size()/2;
      os << "\"" << qr.sought << "\"" << " occurs " << temp<< " times:" <<std::endl;
      for (auto num : *qr.lines)
      {
        os << "\t(line " << num + 1 << ") " << *(qr.file->begin() + num) << std::endl;
        num_2++;
        if(((num_2)%2 == 0) && (num_2 != qr.lines->size())) os << "\n";
      }
      return os;
    }
  }
  else
  {
    os << "\"" << qr.sought << "\"" << " occurs " << 
        qr.lines->size() << " times:" <<std::endl;
    for (auto num : *qr.lines)
    {
        os << "\t(line " << num + 1 << ") " 
            << *(qr.file->begin() + num) << std::endl;
    }
    return os;
  }
}


/////////////////////////////////////////////////////////